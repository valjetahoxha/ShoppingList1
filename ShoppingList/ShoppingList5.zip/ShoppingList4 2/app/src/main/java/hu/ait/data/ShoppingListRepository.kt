package hu.ait.data

import android.content.Context
import androidx.lifecycle.LiveData
import hu.ait.data.ShoppingItem
import hu.ait.data.ShoppingItemDao

class ShoppingListRepository (context: Context) {

    private val shoppingItemDao: ShoppingItemDao

    init {
        val database = ShoppingDatabase.getDatabase(context)
        shoppingItemDao = database.shoppingItemDao()
    }

    fun getAllItems(): LiveData<List<ShoppingItem>> {
        return shoppingItemDao.getAllItems()
    }

    suspend fun insertItem(item: ShoppingItem) {
        shoppingItemDao.insertItem(item)
    }

    suspend fun deleteItem(item: ShoppingItem) {
        shoppingItemDao.deleteItem(item)
    }

    suspend fun updateItem(item: ShoppingItem) {
        shoppingItemDao.updateItem(item)
    }

    suspend fun deleteAllItems() {
        shoppingItemDao.deleteAllItems()
    }

    fun getTotalPrice(): LiveData<Float> {
        return shoppingItemDao.getTotalPrice()
    }

    fun getItemByIdFlow(id: Int): LiveData<ShoppingItem> {
        return shoppingItemDao.getItemByIdFlow(id)
    }

    suspend fun getItemById(id: Int): ShoppingItem? {
        return shoppingItemDao.getItemById(id)
    }

    fun searchItems(name: String): LiveData<List<ShoppingItem>> {
        return shoppingItemDao.searchItems(name)
    }

    fun filterItemsByPrice(minPrice: Float, maxPrice: Float): LiveData<List<ShoppingItem>> {
        return shoppingItemDao.filterItemsByPrice(minPrice, maxPrice)
    }

    fun filterItemsByCategory(category: String): LiveData<List<ShoppingItem>> {
        return shoppingItemDao.filterItemsByCategory(category)
    }
}