package hu.ait.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import hu.ait.data.ShoppingItem
import hu.ait.shoppinglist.ShoppingViewModel


@Composable
fun AddEditItemScreen(
    viewModel: ShoppingViewModel,
    itemId: Int,
    navController: NavHostController,
    onNavigateBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    LaunchedEffect(itemId) {
        if (itemId != -1) {
            val item = viewModel.getItemById(itemId)
            if (item != null) {
                name = item.name
                description = item.description
                price = item.price.toString()
                category = item.category
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = price,
            onValueChange = { price = it },
            label = { Text("Price") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") }
        )
        Row(
            horizontalArrangement = Arrangement.End,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    if (name.isBlank() || description.isBlank() || price.isBlank() || category.isBlank()) {
                        errorMessage = "Please fill in all fields."
                        showError = true
                    } else {
                        try {
                            val priceValue = price.toDouble()
                            val newItem = ShoppingItem(
                                name = name,
                                description = description,
                                price = priceValue,
                                category = category,
                                bought = false
                            )
                            if (itemId == -1) {
                                viewModel.addItem(newItem)
                            } else {
                                newItem.id = itemId
                                viewModel.updateItem(newItem)
                            }
                            onNavigateBack()
                        } catch (e: NumberFormatException) {
                            errorMessage = "Please enter a valid price."
                            showError = true
                        }
                    }
                },
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text("Save")
            }
        }
        if (showError) {
            Text(text = errorMessage, color = Color.Red, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
