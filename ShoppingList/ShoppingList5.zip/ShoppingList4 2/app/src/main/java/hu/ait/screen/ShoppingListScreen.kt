package hu.ait.screen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import hu.ait.navigation.MainNavigation
import hu.ait.screen.AddEditItemScreen
import hu.ait.screen.ShoppingListScreen
import hu.ait.shoppinglist.ui.theme.ShoppingListTheme


import hu.ait.data.ShoppingItem
import hu.ait.shoppinglist.ShoppingViewModel

@Composable
fun ShoppingListScreen(
    viewModel: ShoppingViewModel,
    onItemClick: (Int) -> Unit,
    onAddItem: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Title") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = price,
            onValueChange = { price = it },
            label = { Text("Price") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.fillMaxWidth()
        )
        Row {
            Button(onClick = {
                if (title.isBlank() || description.isBlank() || price.isBlank() || category.isBlank()) {
                    errorMessage = "Please fill in all fields."
                    showError = true
                } else {
                    try {
                        val priceValue = price.toDouble()
                        val newItem = ShoppingItem(
                            name = title,
                            description = description,
                            price = priceValue,
                            category = category,
                            bought = false
                        )
                        viewModel.addItem(newItem)
                        title = ""
                        description = ""
                        price = ""
                        category = ""
                        showError = false
                    } catch (e: NumberFormatException) {
                        errorMessage = "Please enter a valid price."
                        showError = true
                    }
                }
            }) {
                Text("Add Item")
            }
        }
        if (showError) {
            Text(text = errorMessage, color = Color.Red)
        }
    }


    @Composable
    fun ShoppingListItem(item: ShoppingItem, onItemClick: (Int) -> Unit) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column {
                Text(text = item.name)
                Text(text = item.description)
                Text(text = item.getPriceString())
                Text(text = item.category)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Checkbox(
                checked = item.bought,
                onCheckedChange = {
                    item.bought = it
                    onItemClick(item.id)


                }
            )
        }
    }
}