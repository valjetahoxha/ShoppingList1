package hu.ait.shoppinglist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

import hu.ait.data.ShoppingListRepository
import hu.ait.navigation.MainNavigation
import hu.ait.screen.AddEditItemScreen
import hu.ait.screen.ShoppingListScreen
import hu.ait.screen.SplashScreen


import hu.ait.shoppinglist.ui.theme.ShoppingListTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShoppingListTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ShoppingListApp()
                }
            }
        }
    }
}

@Composable
fun ShoppingListApp() {
val navController = rememberNavController()
    val repository = ShoppingListRepository(LocalContext.current)
    val viewModel: ShoppingViewModel = viewModel(
        factory = ShoppingViewModelFactory(repository

        )


    )

    NavHost(
        navController = navController,
        startDestination = MainNavigation.SplashScreen.route
    ) {
        composable(route = MainNavigation.SplashScreen.route) {
            SplashScreen(onSplashCompleted = {
                navController.navigate(MainNavigation.ShoppingListScreen.route) {
                    popUpTo(MainNavigation.SplashScreen.route) { inclusive = true }
                }
            })
        }
        composable(route = MainNavigation.ShoppingListScreen.route) {
            ShoppingListScreen(
                viewModel = viewModel,
                onItemClick = { itemId ->
                    navController.navigate("${MainNavigation.AddEditItemScreen.route}/$itemId")
                },
                onAddItem = {
                    navController.navigate(MainNavigation.AddEditItemScreen.route)
                }
            )
        }
        composable(
            route = MainNavigation.AddEditItemScreen.route,
            arguments = listOf(navArgument("itemId") { type = NavType.IntType })
        ) { backStackEntry ->
            val itemId = backStackEntry.arguments?.getInt("itemId") ?: -1
            AddEditItemScreen(
                viewModel = viewModel,
                itemId = itemId,
                navController = navController,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
