package hu.ait.data

import androidx.room.*
import androidx.lifecycle.LiveData
import androidx.room.Query
import hu.ait.data.ShoppingItem


interface ShoppingItemDao {

    @Query("SELECT * FROM shopping_items")
    fun getAllItems(): LiveData<List<ShoppingItem>>

    @Insert
    suspend fun insertItem(item: ShoppingItem)

    @Delete
    suspend fun deleteItem(item: ShoppingItem)

    @Update
    suspend fun updateItem(item: ShoppingItem)

    @Query("DELETE FROM shopping_items")
    suspend fun deleteAllItems()

    @Query("SELECT SUM(price) FROM shopping_items")
    fun getTotalPrice(): LiveData<Float>

    @Query("SELECT * FROM shopping_items WHERE id = :id")
    fun getItemByIdFlow(id: Int): LiveData<ShoppingItem>

    @Query("SELECT * FROM shopping_items WHERE id = :id")
    suspend fun getItemById(id: Int): ShoppingItem?

    @Query("SELECT * FROM shopping_items WHERE name LIKE '%' || :name || '%'")
    fun searchItems(name: String): LiveData<List<ShoppingItem>>

    @Query("SELECT * FROM shopping_items WHERE price >= :minPrice AND price <= :maxPrice")
    fun filterItemsByPrice(minPrice: Float, maxPrice: Float): LiveData<List<ShoppingItem>>

    @Query("SELECT * FROM shopping_items WHERE category = :category")
    fun filterItemsByCategory(category: String): LiveData<List<ShoppingItem>>
}